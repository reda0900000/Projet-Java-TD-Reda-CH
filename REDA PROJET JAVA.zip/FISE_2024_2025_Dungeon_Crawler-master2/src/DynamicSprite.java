import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class DynamicSprite extends SolidSprite {
    private Direction direction = Direction.EAST;
    private double speed = 5; // Vitesse de base
    private double timeBetweenFrame = 250;
    private final int spriteSheetNumberOfColumn = 10;

    private int maxHealth = 100; // Santé maximale
    private int currentHealth = 100; // Santé actuelle
    private int health;

    public DynamicSprite(double x, double y, Image image, double width, double height) {
        super(x, y, image, width, height);
    }

    public double getSpeed() {
        return this.speed;
    }

    public void setSpeed(double newSpeed) {
        this.speed = newSpeed;
    }

    public void decreaseHealth(int amount) {
        currentHealth -= amount;
        if (currentHealth < 0) currentHealth = 0;
    }

    public void increaseHealth(int amount) {
        currentHealth += amount;
        if (currentHealth > maxHealth) currentHealth = maxHealth;
    }

    private boolean isMovingPossible(ArrayList<Sprite> environment) {
        Rectangle2D.Double moved = new Rectangle2D.Double();
        switch (direction) {
            case EAST:
                moved.setRect(super.getHitBox().getX() + speed, super.getHitBox().getY(),
                        super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case WEST:
                moved.setRect(super.getHitBox().getX() - speed, super.getHitBox().getY(),
                        super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case NORTH:
                moved.setRect(super.getHitBox().getX(), super.getHitBox().getY() - speed,
                        super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
            case SOUTH:
                moved.setRect(super.getHitBox().getX(), super.getHitBox().getY() + speed,
                        super.getHitBox().getWidth(), super.getHitBox().getHeight());
                break;
        }

        for (Sprite s : environment) {
            if ((s instanceof SolidSprite) && (s != this)) {
                if (((SolidSprite) s).intersect(moved)) {
                    return false;
                }
            }
        }
        return true;
    }

    private void move() {
        switch (direction) {
            case NORTH -> this.y -= speed;
            case SOUTH -> this.y += speed;
            case EAST -> this.x += speed;
            case WEST -> this.x -= speed;
        }
    }

    public void moveIfPossible(ArrayList<Sprite> environment) {
        if (isMovingPossible(environment)) {
            move();
        }
    }

    @Override
    public void draw(Graphics g) {
        // Dessin de l'animation du personnage
        int index = (int) (System.currentTimeMillis() / timeBetweenFrame % spriteSheetNumberOfColumn);

        g.drawImage(image, (int) x, (int) y, (int) (x + width), (int) (y + height),
                (int) (index * this.width), (int) (direction.getFrameLineNumber() * height),
                (int) ((index + 1) * this.width), (int) ((direction.getFrameLineNumber() + 1) * this.height), null);

        // Dessin de la barre de vie au-dessus du personnage
        drawHealthBar(g);
    }

    private void drawHealthBar(Graphics g) {
        int barWidth = 50; // Largeur de la barre de vie
        int barHeight = 5; // Hauteur de la barre de vie
        int xBar = (int) (x + (width - barWidth) / 2); // Centré au-dessus de la tête
        int yBar = (int) (y - 10); // Position légèrement au-dessus du personnage

        // Calcul du ratio de santé
        double healthRatio = (double) currentHealth / maxHealth;

        // Dessiner le fond de la barre (rouge)
        g.setColor(Color.RED);
        g.fillRect(xBar, yBar, barWidth, barHeight);

        // Dessiner la partie "santé" (vert)
        g.setColor(Color.GREEN);
        g.fillRect(xBar, yBar, (int) (barWidth * healthRatio), barHeight);

        // Optionnel : Dessiner le contour
        g.setColor(Color.BLACK);
        g.drawRect(xBar, yBar, barWidth, barHeight);
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Direction getDirection() {
        return direction;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }
}
